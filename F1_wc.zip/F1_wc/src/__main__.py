from .app import interface

if __name__ == "__main__":
    interface.mainloop()
